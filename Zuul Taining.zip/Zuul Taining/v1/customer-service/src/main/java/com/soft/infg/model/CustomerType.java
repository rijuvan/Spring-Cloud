package com.soft.infg.model;



public enum CustomerType {

	NEW, REGULAR, VIP;
	
}
