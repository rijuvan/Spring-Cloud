package com.soft.infg.model;

public enum OrderStatus {

	NEW, PROCESSING, ACCEPTED, DONE, REJECTED;
	
}
